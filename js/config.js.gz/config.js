﻿export function get_key(key) {
    var syncFusionTemp = "MzkzMDk4MEAzMzMwMmUzMDJlMzAzYjMzMzAzYm0yTzF1dGRVZlpaTlNFczhGc21TSjdXVE1JM3hNOE9QWklSQlBiamVyMDA9;MzkzMDk4MUAzMzMwMmUzMDJlMzAzYjMzMzAzYkNaVHNXUCtnakgydER0WmRzazlZQm5QSHAxK0s5TmR4eER2TlFmV29WWms9";
    return syncFusionTemp;
}
